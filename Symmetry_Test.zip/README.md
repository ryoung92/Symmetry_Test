# Symmetry_Test

fizzbuzz programed in c#

How to Run:  

Navigate to directory of the makefile ./Symmetry_test/MultiFizzBuzz/  
type following commands 

make  

mono PartOne.exe  

mono PartTwo.exe  





