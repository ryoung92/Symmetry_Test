﻿
namespace API
{
    public interface ICondition
    {
        string Condition(int input);

    }
}
