﻿using System;

namespace PartOne
{
    class Program
    {
        static void Main(string[] args)
        {
            new PartOneProgram();
        }
    }
}
